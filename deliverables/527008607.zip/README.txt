
#Assignment 1 README

Student: Maximiliano Torresdey Flores

Highest rank completed: Task 7

No external code downloaded except for the skeleton code already provided.